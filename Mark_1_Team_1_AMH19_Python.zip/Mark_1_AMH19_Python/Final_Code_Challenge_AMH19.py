import cv2
import numpy as np
import tensorflow as tf
from mtcnn import MTCNN
import socket
import time


# Load my trained model oh yeahhh
model = tf.keras.models.load_model("facial_amh19_model.h5")

# Emotion labels (this one is already set in the database that Nat sent me)
emotion_labels = ["Angry", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprise"]
detector = MTCNN()

# Configuración UDP
UDP_IP = "127.0.0.1"
UDP_PORT = 5005
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)


# Variables for "Smiling" detection
surprise_start_time = None
surprise_threshold = 3  # Seconds required to activate "Time to eat"


# Function to detect faces and classify emotions
def detect_and_classify(frame):
    global surprise_start_time
    faces = detector.detect_faces(frame)

    for face in faces:
        x, y, width, height = face['box']
        x, y = abs(x), abs(y)
        face_roi = frame[y:y+height, x:x+width]

        face_resized = cv2.resize(face_roi, (48, 48))
        face_gray = cv2.cvtColor(face_resized, cv2.COLOR_BGR2GRAY)
        face_array = np.expand_dims(face_gray, axis=0)
        face_array = np.expand_dims(face_array, axis=-1)
        face_array = np.repeat(face_array, 3, axis=-1)
        face_array = face_array / 255.0

        prediction = model.predict(face_array)
        emotion_index = np.argmax(prediction)
        emotion_text = emotion_labels[emotion_index]

        # Detectar Happy sostenido
        if emotion_text == "Happy":
            if surprise_start_time is None:
                surprise_start_time = time.time()
            elif time.time() - surprise_start_time >= surprise_threshold:
                # Cambiar texto en pantalla
                emotion_text = "About to eat, please stay still"
                # Enviar señal '1' a Simulink
                sock.sendto(b'1', (UDP_IP, UDP_PORT))
                print("😄 Emoción Happy mantenida 3s → Enviando '1'")
        else:
            surprise_start_time = None
            sock.sendto(b'0', (UDP_IP, UDP_PORT))
            print(f"😐 Emoción: {emotion_text} → Enviando '0'")

        # Mostrar texto en pantalla
        cv2.rectangle(frame, (x, y), (x+width, y+height), (255, 0, 0), 2)
        cv2.putText(frame, emotion_text, (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

    return frame

def run_webcam():
    video_capture = cv2.VideoCapture(0)
    while True:
        ret, frame = video_capture.read()
        if not ret:
            break

        frame = detect_and_classify(frame)
        cv2.imshow("Smile 5 seconds to launch the Mark 1", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    video_capture.release()
    cv2.destroyAllWindows()

run_webcam()
