clear; close; clc

% Vector temporal
t_max = 10;
t = linspace(0, t_max, 100)';

% Movimiento en fases:
% 1. Baja la cuchara (0s - 3s)
% 2. Pausa simulando que toma la comida (3s - 4s)
% 3. Sube la cuchara (4s - 6s)
% 4. Se mueve a la boca (6s - 9s)
% 5. Pausa en la boca para entregar la comida (9s - 10s)

% Ángulos iniciales en posición "casa" (supongo que todo está a 0° o 90°)
q_inicial = [0, 0, 0, 0, 0]; % Modifica si tu robot tiene otra configuración

% Ángulos intermedios y finales para cada fase
q_bajar = [-pi/4, -pi/4, -pi/4, -pi/4, -pi/4]; % Baja hacia la mesa
q_subir = [pi/6, pi/6, pi/6, pi/6, pi/6]; % Sube con la comida
q_a_boca = [pi/3, pi/6, pi/6, pi/4, pi/3]; % Lleva a la boca
q_final = q_a_boca; % Se queda ahí

% Definir trayectorias por fase
T1 = linspace(0, 3, 30)';  % Baja a la mesa
T2 = linspace(3, 4, 10)';  % Pausa (simula tomar comida)
T3 = linspace(4, 6, 20)';  % Sube con la comida
T4 = linspace(6, 9, 30)';  % Mueve a la boca
T5 = linspace(9, 10, 10)'; % Pausa en la boca

% Crear las trayectorias interpoladas
Q1 = [T1, linspace(q_inicial(1), q_bajar(1), length(T1))';
      T2, repmat(q_bajar(1), length(T2), 1);
      T3, linspace(q_bajar(1), q_subir(1), length(T3))';
      T4, linspace(q_subir(1), q_a_boca(1), length(T4))';
      T5, repmat(q_a_boca(1), length(T5), 1)];

Q2 = [T1, linspace(q_inicial(2), q_bajar(2), length(T1))';
      T2, repmat(q_bajar(2), length(T2), 1);
      T3, linspace(q_bajar(2), q_subir(2), length(T3))';
      T4, linspace(q_subir(2), q_a_boca(2), length(T4))';
      T5, repmat(q_a_boca(2), length(T5), 1)];

Q3 = [T1, linspace(q_inicial(3), q_bajar(3), length(T1))';
      T2, repmat(q_bajar(3), length(T2), 1);
      T3, linspace(q_bajar(3), q_subir(3), length(T3))';
      T4, linspace(q_subir(3), q_a_boca(3), length(T4))';
      T5, repmat(q_a_boca(3), length(T5), 1)];

Q4 = [T1, linspace(q_inicial(4), q_bajar(4), length(T1))';
      T2, repmat(q_bajar(4), length(T2), 1);
      T3, linspace(q_bajar(4), q_subir(4), length(T3))';
      T4, linspace(q_subir(4), q_a_boca(4), length(T4))';
      T5, repmat(q_a_boca(4), length(T5), 1)];

Q5 = [T1, linspace(q_inicial(5), q_bajar(5), length(T1))';
      T2, repmat(q_bajar(5), length(T2), 1);
      T3, linspace(q_bajar(5), q_subir(5), length(T3))';
      T4, linspace(q_subir(5), q_a_boca(5), length(T4))';
      T5, repmat(q_a_boca(5), length(T5), 1)];

% Simulación
sim('AMH19_Mark1_Complete_URDF.slx')
