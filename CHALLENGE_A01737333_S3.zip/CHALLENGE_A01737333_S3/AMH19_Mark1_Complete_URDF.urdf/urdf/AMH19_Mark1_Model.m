%IMPORTING THE URDF MODEL TO SIMULIK

%smimport('AMH19_Mark1_Complete_URDF.urdf')
%open_system('AMH19_Mark1_URDF')
mark1 = importrobot("AMH19_Mark1_Complete_URDF.urdf");
show(mark1);

config = homeConfiguration(mark1);
show(mark1,config);


figure;
for theta = linspace(0,pi/4,50)
    config(1).JointPosition = theta; %Adjustin desired joint
    show(mark1,config);
    pause(0.1)
end
